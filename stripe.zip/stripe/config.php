<?php
return [
    'id' => 'stripe',
    'name' => 'Stripe',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => '',
    'color' => '#74788d',
];